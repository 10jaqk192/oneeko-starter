
export default function Home() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>🚀 Welcome to Oneeko.ai</h1>
      <p>This is your starter landing page built with Next.js</p>
    </div>
  );
}

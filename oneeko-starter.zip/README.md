
# Oneeko Starter

This is a minimal Next.js landing page for Oneeko.ai
